# Vexel Mine-imator — native macOS Apple Silicon build

This directory turns the supplied Mine-imator / Simply Upscaled source base into a **native arm64 macOS application** for Apple Silicon Macs (M1 and newer). It does not use Wine, CrossOver, Rosetta, DXVK, or Direct3D.

## What changed

- `CppProject/CMakeLists.txt` can target `arm64` directly on macOS.
- macOS uses the source project's existing OpenGL renderer (`API_OPENGL=1`).
- Native Homebrew arm64 builds of Qt 5, FFmpeg, OpenAL, libzip, x264, FreeType, zlib and OpenMP are used instead of the repository's old prebuilt Intel `.a` files.
- CMake emits a real `.app` bundle.
- `macdeployqt` and `dylibbundler` collect runtime libraries into the app bundle.
- The final app is ad-hoc signed for personal/local use.
- GML has already been converted to C++ with `CppGen` on EnderPC, so the Mac does not need the .NET parser.

## Build on an M1 MacBook

1. Copy this whole repository to the Mac.
2. In Finder, open `MacM1`.
3. Double-click `bootstrap-and-build.command`.
4. If macOS asks for Xcode Command Line Tools or a password for Homebrew, finish that step and run the command again.
5. When it succeeds, the finished app is:

   `dist-macos-m1/Vexel Mine-imator M1 Ender.app`

   and the distributable archive is:

   `dist-macos-m1/VexelMineimator-M1-Ender.zip`

   and the normal drag-to-Applications installer image is:

   `dist-macos-m1/VexelMineimator-M1-Ender.dmg`

Run `verify-m1.command` for an architecture/signature/dependency smoke test.

## Qt fallback

The script first tries Homebrew `qt@5`. If Homebrew no longer provides it, it automatically builds the maintained KDE Qt 5.15 `qtbase` branch natively for arm64. This takes longer only on the first build.

## Authentication

No account, Discord, license, or Vexel authentication is bypassed by this port. If a later Vexel-specific source layer performs official authentication, that flow remains intact.

## Source-base note

The GitHub repository supplied for this port currently identifies itself in source as **Mine-imator 2.0.2 Simply Upscaled Build**. This M1 work ports that source base natively. Vexel-only proprietary changes that are not present in the supplied source cannot be recreated merely by renaming the application.
