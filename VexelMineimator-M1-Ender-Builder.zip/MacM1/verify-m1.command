#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
APP="$ROOT/dist-macos-m1/Vexel Mine-imator M1 Ender.app"
EXE="$APP/Contents/MacOS/Mine-imator"

if [[ ! -x "$EXE" ]]; then
  echo "App not found. Run MacM1/bootstrap-and-build.command first."
  exit 1
fi

echo "macOS: $(sw_vers -productVersion)"
echo "Machine: $(uname -m)"
echo "Binary: $(file "$EXE")"
echo "Architectures: $(lipo -archs "$EXE")"
echo
echo "Code signature:"
codesign --verify --deep --strict --verbose=2 "$APP"
echo
echo "Non-system dynamic dependencies:"
otool -L "$EXE" | grep -vE '^\s*(/System/Library|/usr/lib)' || true
echo
echo "Launching for smoke test..."
open "$APP"
