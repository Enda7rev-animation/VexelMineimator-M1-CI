#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
BUILD_DIR="$ROOT/build-macos-m1"
DIST_DIR="$ROOT/dist-macos-m1"
DEPS_DIR="$ROOT/.m1-deps"

say() { printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }
die() { printf '\n\033[1;31mERROR: %s\033[0m\n' "$*" >&2; exit 1; }

[[ "$(uname -s)" == "Darwin" ]] || die "This build must be run on macOS."
[[ "$(uname -m)" == "arm64" ]] || die "This package targets Apple Silicon (M1/M2/M3/M4/M5). Current architecture: $(uname -m)"

say "Checking Xcode Command Line Tools"
if ! xcode-select -p >/dev/null 2>&1; then
  xcode-select --install || true
  die "Finish installing Xcode Command Line Tools, then run this file again."
fi

say "Checking Homebrew"
if [[ -x /opt/homebrew/bin/brew ]]; then
  eval "$(/opt/homebrew/bin/brew shellenv)"
elif ! command -v brew >/dev/null 2>&1 || [[ "$(brew --prefix 2>/dev/null || true)" != "/opt/homebrew" ]]; then
  echo "A native Apple Silicon Homebrew installation is required at /opt/homebrew."
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
  if [[ -x /opt/homebrew/bin/brew ]]; then
    eval "$(/opt/homebrew/bin/brew shellenv)"
  fi
fi
command -v brew >/dev/null 2>&1 || die "Homebrew was not found after installation."
[[ "$(brew --prefix)" == "/opt/homebrew" ]] || die "Intel/Rosetta Homebrew detected. Native /opt/homebrew is required."

say "Installing native arm64 build dependencies"
brew install cmake ninja pkg-config libomp libzip openal-soft ffmpeg x264 freetype dylibbundler git

# CI can provide ccache to make iterative M1 port fixes much faster. It is
# optional for normal end users building this package on their own Mac.
CCACHE_CMAKE_ARGS=()
if command -v ccache >/dev/null 2>&1; then
  ccache --max-size=2G >/dev/null 2>&1 || true
  CCACHE_CMAKE_ARGS+=("-DCMAKE_CXX_COMPILER_LAUNCHER=$(command -v ccache)")
fi

QT_PREFIX=""
if brew info qt@5 >/dev/null 2>&1; then
  brew install qt@5 || true
  if [[ -x "$(brew --prefix qt@5 2>/dev/null)/bin/qmake" ]]; then
    QT_PREFIX="$(brew --prefix qt@5)"
  fi
fi

build_qt5_fallback() {
  local qt_src="$DEPS_DIR/src/qtbase-5.15-kde"
  local qt_prefix="$DEPS_DIR/qt5-arm64"
  mkdir -p "$DEPS_DIR/src"

  if [[ ! -d "$qt_src/.git" ]]; then
    say "Homebrew qt@5 unavailable; cloning maintained Qt 5.15 qtbase"
    git clone --depth 1 --branch kde/5.15 https://invent.kde.org/qt/qt/qtbase.git "$qt_src"
  fi

  if [[ ! -x "$qt_prefix/bin/qmake" ]]; then
    say "Building Qt 5.15 natively for arm64 (one-time, can take a while)"
    rm -rf "$qt_src/build-m1"
    mkdir -p "$qt_src/build-m1"
    pushd "$qt_src/build-m1" >/dev/null
    ../configure \
      -prefix "$qt_prefix" \
      -opensource -confirm-license \
      -release -static \
      -nomake examples -nomake tests \
      -no-openssl -securetransport \
      -opengl desktop
    make -j"$(sysctl -n hw.ncpu)"
    make install
    popd >/dev/null
  fi
  QT_PREFIX="$qt_prefix"
}

[[ -n "$QT_PREFIX" ]] || build_qt5_fallback
[[ -x "$QT_PREFIX/bin/qmake" ]] || die "Qt 5 build is missing qmake: $QT_PREFIX"

LIBOMP_PREFIX="$(brew --prefix libomp)"

# Make pkg-config resolve only native arm64 Homebrew packages first.
PKG_DIRS=()
for formula in libzip openal-soft ffmpeg x264 freetype; do
  prefix="$(brew --prefix "$formula")"
  [[ -d "$prefix/lib/pkgconfig" ]] && PKG_DIRS+=("$prefix/lib/pkgconfig")
  [[ -d "$prefix/share/pkgconfig" ]] && PKG_DIRS+=("$prefix/share/pkgconfig")
done
export PKG_CONFIG_PATH="$(IFS=:; echo "${PKG_DIRS[*]}")${PKG_CONFIG_PATH:+:$PKG_CONFIG_PATH}"

say "Configuring Mine-imator for Apple Silicon arm64"
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR" "$DIST_DIR"

cmake -S "$ROOT/CppProject" -B "$BUILD_DIR" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_OSX_ARCHITECTURES=arm64 \
  -DCMAKE_OSX_DEPLOYMENT_TARGET=11.0 \
  -DMINEIMATOR_MAC_ARCH=arm64 \
  -DMINEIMATOR_MAC_MIN_VERSION=11.0 \
  -DMINEIMATOR_MAC_HOMEBREW=ON \
  -DCMAKE_PREFIX_PATH="$QT_PREFIX;$LIBOMP_PREFIX" \
  -DOpenMP_CXX_FLAGS="-Xpreprocessor -fopenmp -I$LIBOMP_PREFIX/include" \
  -DOpenMP_CXX_LIB_NAMES=omp \
  -DOpenMP_omp_LIBRARY="$LIBOMP_PREFIX/lib/libomp.dylib" \
  "${CCACHE_CMAKE_ARGS[@]}"

say "Compiling native M1 application"
if [[ "${GITHUB_ACTIONS:-}" == "true" ]]; then
  # During CI porting, keep compiling independent translation units after an
  # error so one runner pass reveals all remaining Clang blockers.
  cmake --build "$BUILD_DIR" --parallel "$(sysctl -n hw.ncpu)" -- -k 0
else
  cmake --build "$BUILD_DIR" --parallel "$(sysctl -n hw.ncpu)"
fi

APP="$BUILD_DIR/Mine-imator.app"
EXE="$APP/Contents/MacOS/Mine-imator"
[[ -x "$EXE" ]] || die "Build finished but the app executable was not found: $EXE"

say "Copying Mine-imator data into the app bundle"
mkdir -p "$APP/Contents/MacOS"
rsync -a "$ROOT/GmProject/datafiles/" "$APP/Contents/MacOS/"

if [[ -x "$QT_PREFIX/bin/macdeployqt" ]] && otool -L "$EXE" | grep -qE 'Qt(Core|Gui|Widgets|Network)|Qt.*\.framework'; then
  say "Bundling Qt frameworks"
  "$QT_PREFIX/bin/macdeployqt" "$APP" -always-overwrite
else
  say "Qt is static (or no dynamic Qt dependency was found); macdeployqt is not required"
fi

say "Bundling Homebrew runtime libraries"
mkdir -p "$APP/Contents/Frameworks"
if command -v dylibbundler >/dev/null 2>&1; then
  if ! dylibbundler -od -b \
      -x "$EXE" \
      -d "$APP/Contents/Frameworks" \
      -p '@executable_path/../Frameworks'; then
    echo "WARNING: dylibbundler could not bundle every library."
    echo "The app can still run on this Mac because Homebrew dependencies are installed."
  fi
fi

# Homebrew Qt 5 plugins can retain their original LC_ID_DYLIB after
# macdeployqt even though their actual Qt dependencies have been rewritten to
# the app bundle.  Normalize those self install-names so the finished app has
# no Homebrew identity baked into bundled dylibs/plugins.
say "Normalizing bundled dylib install names"
while IFS= read -r -d '' macho; do
  if ! file "$macho" 2>/dev/null | grep -q 'Mach-O'; then
    continue
  fi
  dylib_id="$(otool -D "$macho" 2>/dev/null | sed -n '2p' | sed 's/^[[:space:]]*//')"
  if [[ "$dylib_id" == /opt/homebrew/* ]]; then
    install_name_tool -id "@rpath/$(basename "$macho")" "$macho"
  fi
done < <(find "$APP" -type f -print0)

say "Applying app name and local ad-hoc signature"
PLIST="$APP/Contents/Info.plist"
if [[ -f "$PLIST" ]]; then
  /usr/libexec/PlistBuddy -c "Set :CFBundleDisplayName Vexel Mine-imator M1 Ender" "$PLIST" 2>/dev/null || \
    /usr/libexec/PlistBuddy -c "Add :CFBundleDisplayName string 'Vexel Mine-imator M1 Ender'" "$PLIST"
  /usr/libexec/PlistBuddy -c "Set :CFBundleName Vexel Mine-imator M1 Ender" "$PLIST" 2>/dev/null || true
  /usr/libexec/PlistBuddy -c "Set :CFBundleIdentifier com.kiraa.vexelmineimator.m1" "$PLIST" 2>/dev/null || true
fi

xattr -cr "$APP" || true
codesign --force --deep --sign - "$APP"
codesign --verify --deep --strict --verbose=2 "$APP"

say "Verifying that the executable is native arm64"
ARCHS="$(lipo -archs "$EXE")"
echo "Architectures: $ARCHS"
[[ " $ARCHS " == *" arm64 "* ]] || die "The final executable is not arm64."
file "$EXE"

if [[ -d "$APP/Contents/Frameworks" ]]; then
  say "Verifying bundled Mach-O libraries"
  while IFS= read -r -d '' lib; do
    if file "$lib" 2>/dev/null | grep -q 'Mach-O'; then
      lib_archs="$(lipo -archs "$lib" 2>/dev/null || true)"
      if [[ -n "$lib_archs" && " $lib_archs " != *" arm64 "* ]]; then
        die "Non-arm64 bundled library detected: $lib ($lib_archs)"
      fi
    fi
  done < <(find "$APP/Contents/Frameworks" -type f -print0)
fi

say "Creating final app, ZIP and DMG"
FINAL_APP="$DIST_DIR/Vexel Mine-imator M1 Ender.app"
FINAL_ZIP="$DIST_DIR/VexelMineimator-M1-Ender.zip"
FINAL_DMG="$DIST_DIR/VexelMineimator-M1-Ender.dmg"
DMG_STAGE="$DIST_DIR/.dmg-stage"
rm -rf "$FINAL_APP" "$FINAL_ZIP" "$FINAL_DMG" "$DMG_STAGE"
ditto "$APP" "$FINAL_APP"
ditto -c -k --sequesterRsrc --keepParent "$FINAL_APP" "$FINAL_ZIP"

# Create a normal drag-to-Applications DMG.  This is the distributable form
# end users can open directly; Xcode/Command Line Tools are only needed on the
# machine that performs this build.
mkdir -p "$DMG_STAGE"
ditto "$FINAL_APP" "$DMG_STAGE/$(basename "$FINAL_APP")"
ln -s /Applications "$DMG_STAGE/Applications"
hdiutil create \
  -volname "Vexel Mine-imator M1 Ender" \
  -srcfolder "$DMG_STAGE" \
  -ov \
  -format UDZO \
  "$FINAL_DMG"
rm -rf "$DMG_STAGE"

hdiutil verify "$FINAL_DMG"

echo
echo "SUCCESS"
echo "App: $FINAL_APP"
echo "ZIP: $FINAL_ZIP"
echo "DMG: $FINAL_DMG"
echo
echo "Open the app with:"
echo "  open \"$FINAL_APP\""
open "$DIST_DIR" >/dev/null 2>&1 || true
