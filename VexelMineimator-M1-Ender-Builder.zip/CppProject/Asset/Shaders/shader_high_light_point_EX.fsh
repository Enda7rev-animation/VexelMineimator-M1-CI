#define SQRT05 0.707106781
#define PI 3.14159265
#define NOISE_SAMPLES 16.0
#define GOLDEN_ANGLE 2.399963

uniform sampler2D uTexture; // static
uniform int uIsSky;
uniform int uIsWater;

uniform float uSampleIndex;
uniform int uAlphaHash;

uniform vec3 uLightPosition; // static
uniform vec4 uLightColor; // static
uniform float uLightStrength; // static
uniform float uLightNear; // static
uniform float uLightFar; // static
uniform float uLightFadeSize; // static
uniform vec3 uShadowPosition; // static
uniform float uLightSpecular;
uniform float uLightSize;
uniform float uNormalStrength;
uniform float uBias;
uniform vec2 uKernel2D;
uniform bool uIgnore;
uniform bool uParaboloid;

uniform sampler2D uDepthBuffer; // static
uniform float uDepthBufferSize; // static

uniform vec3 uCameraPosition; // static

uniform sampler2D uTextureMaterial; // static
uniform sampler2D uTextureNormal; // static
uniform int uMaterialFormat;
uniform float uDefaultEmissive;
uniform float uDefaultSubsurface;
uniform float uRoughness;
uniform float uMetallic;
uniform float uEmissive;

uniform float uSSS;
uniform vec3 uSSSRadius;
uniform vec4 uSSSColor;
uniform float uSSSStrength;
uniform float uSSSSharpness;
uniform float uSSSDesaturation;
uniform float uSSSColorThreshold;
uniform float uAbsorption;
uniform float uSSSHighlight;
uniform float uSSSHighlightStrength;
uniform float uSSSHighlightSharpness;
uniform float uSSSHighlightColorThreshold;
uniform float uSSSHighlightDesaturation;
uniform bool uSSSHighQuality;
uniform float uShadowBlurSample;

varying vec3 vPosition;
varying vec3 vNormal;
varying vec3 vTangent;
varying mat3 vTBN;
varying vec2 vTexCoord;
varying vec4 vCustom;
varying vec4 vColor;

// Improved noise functions
float hash(vec2 c)
{
	return fract(10000.0 * sin(17.0 * c.x + 0.1 * c.y) *
	(0.1 + abs(sin(13.0 * c.y + c.x))));
}

float noise(vec2 p)
{
    vec2 ip = floor(p);
    vec2 u = fract(p);
    u = u*u*(3.0-2.0*u);
    
    float res = mix(mix(hash(ip), hash(ip+vec2(1.0,0.0)), u.x), mix(hash(ip+vec2(0.0,1.0)), hash(ip+vec2(1.0,1.0)), u.x), u.y);
    return res*res;
}

// Fresnel and PBR functions
float fresnelSchlickRoughness(float cosTheta, float F0, float roughness)
{
    return F0 + (max((1.0 - roughness), F0) - F0) * pow(clamp(1.0 - cosTheta, 0.0, 1.0), 5.0);
}

float distributionGGX(vec3 N, vec3 H, float roughness)
{
    float a2 = roughness * roughness * roughness * roughness;
    float NdotH = max(dot(N, H), 0.0);
    float denom = (NdotH * NdotH * (a2 - 1.0) + 1.0);
    return a2 / (PI * denom * denom);
}

float geometrySchlickGGX(float NdotV, float roughness)
{
    float r = (roughness + 1.0);
    float k = (r * r) / 8.0;
    return NdotV / (NdotV * (1.0 - k) + k);
}

float geometrySmith(vec3 N, vec3 V, vec3 L, float roughness)
{
    return geometrySchlickGGX(max(dot(N, V), 0.0), roughness) *
            geometrySchlickGGX(max(dot(N, L), 0.0), roughness);
}

// Normal mapping
uniform int uUseNormalMap; // static
vec3 getMappedNormal(vec2 uv)
{
    if (uUseNormalMap < 1)
        return vec3(vTBN[2][0], vTBN[2][1], vTBN[2][2]);
    
    vec4 n = texture2D(uTextureNormal, uv).rgba;
    n.rgba = (n.a < 0.01 ? vec4(.5, .5, 0.0, 1.0) : n.rgba);
    n.xy = n.xy * 2.0 - 1.0;
	n.z = sqrt(max(0.0, 1.0 - dot(n.xy, n.xy)));
	//n.y *= -1.0; // DirectX fix if needed

	vec3 smoothNormal = normalize(mix(vec3(0.0, 0.0, 1.0), n.xyz, uNormalStrength));
	return normalize(vTBN * smoothNormal);
}

// Depth buffer handling
float unpackDepth(vec4 enc)
{
    return dot(enc, vec4(
        1.0,
        1.0/255.0,
        1.0/65025.0,
        1.0/16581375.0
    ));
}

vec2 getShadowMapCoord(vec3 look)
{
    float tFOV = tan(PI / 4.0);
    vec3 u, v, toPoint = vPosition - uShadowPosition;
    vec2 coord;
    
    look = normalize(look);
    u = vec3(-look.z * look.x, -look.z * look.y, 1.0 - look.z * look.z);
    u = normalize(u) * tFOV; 
    v = normalize(cross(u, look)) * tFOV;
    
    toPoint /= dot(toPoint, look);
    coord.x = dot(toPoint, v) / (2.0 * tFOV) + 0.5;
    coord.y = 0.5 - dot(toPoint, u) / (2.0 * tFOV);
    
    coord.x /= 3.0;
    coord.y *= 0.5;
    coord = clamp(coord, 0.001, 0.999);
    
    return coord;
}

vec4 getFilteredDepth(vec2 uv, vec2 uvMin)
{
    float samples = 0.0;
    vec2 sampleuv, uvMax, texelOffset;
    vec4 color = vec4(0.0);
	if (!uParaboloid) {
		texelOffset = vec2((1.0/vec2(uDepthBufferSize * 3.0, uDepthBufferSize * 2.0)) * 0.5);
		uvMax = uvMin + vec2(1.0/3.0, 0.5);
	}
	else
	{
		texelOffset = vec2(1.0 / uDepthBufferSize, 1.0 / (uDepthBufferSize * 2.0)) * 0.5;
		uvMax = uvMin + vec2(1.0, 0.5);
	}
    
    // Top left
    sampleuv = uv - texelOffset.x;
    if (sampleuv.x > uvMin.x && sampleuv.x < uvMax.x &&
        sampleuv.y > uvMin.y && sampleuv.y < uvMax.y) {
        color += texture2D(uDepthBuffer, sampleuv);
        samples += 1.0;
    }
    
    // Top right
    sampleuv.y = uv.y - texelOffset.x;
    sampleuv.x = uv.x + texelOffset.y;
    if (sampleuv.x > uvMin.x && sampleuv.x < uvMax.x &&
        sampleuv.y > uvMin.y && sampleuv.y < uvMax.y) {
        color += texture2D(uDepthBuffer, sampleuv);
        samples += 1.0;
    }
    
    // Bottom left
    sampleuv.y = uv.y + texelOffset.x;
    sampleuv.x = uv.x - texelOffset.y;
    if (sampleuv.x > uvMin.x && sampleuv.x < uvMax.x &&
        sampleuv.y > uvMin.y && sampleuv.y < uvMax.y) {
        color += texture2D(uDepthBuffer, sampleuv);
        samples += 1.0;
    }
    
    // Bottom right
    sampleuv = uv + texelOffset;
    if (sampleuv.x > uvMin.x && sampleuv.x < uvMax.x &&
        sampleuv.y > uvMin.y && sampleuv.y < uvMax.y) {
        color += texture2D(uDepthBuffer, sampleuv);
        samples += 1.0;
    }
    
    return color / samples;
}

// Shadow calculation with subsurface scattering
float calculateShadow(vec2 fragCoord, vec2 bufferMin, float fragDepth, float bias, float att, out vec3 subsurf, out vec3 subsurfHighlight, float sss)
{
    float shadow = 0.0;
    float weightSum = 0.0;
    subsurf = vec3(0.0);
    subsurfHighlight = vec3(0.0);
    
	if (!uIgnore)
	{
	    if (uLightSize > 0.0001)
		{
	        float texelsize = uLightSize / uKernel2D[1] / 3.0;
		
	        for (int i = 0; i < 128; i++)
			{
				if (i > int(uShadowBlurSample))
					break;
				// Golden Sampling
				float r = sqrt(float(i)+0.5) / sqrt(float(uShadowBlurSample));
				float theta = float(i) * GOLDEN_ANGLE + uKernel2D[0];

				vec2 sampleOffset = vec2(cos(theta), sin(theta)) * r * texelsize;
	            vec2 sampleCoord = fragCoord + sampleOffset;

	            vec2 clampedCoord = clamp(
	                sampleCoord,
	                bufferMin + vec2(0.001),
	                bufferMin + vec2(1.0 / 3.0 - 0.001, 0.5 - 0.001)
	            );

	            float sampleDepth = uLightNear + (uLightFar - uLightNear) *
	                              unpackDepth(getFilteredDepth(clampedCoord, bufferMin));

	            float shadowTest = smoothstep(bias * 0.5, bias * 1.25, fragDepth - sampleDepth);
	            float weight = 1.0 - smoothstep(0.0, uLightSize, length(sampleOffset));
            
	            shadow += (1.0 - shadowTest) * weight;
	            weightSum += weight;

	            // Subsurface scattering
	            if (uSSSHighQuality && sss > 0.001) {
	                vec3 rad, dis, falloff;
                
	                // Main SSS
	                if (uSSSStrength > 0.01) {
	                    rad = uSSSRadius * sss;
	                    dis = vec3((fragDepth + bias) - sampleDepth) / 
	                         (mix(uLightColor.rgb, vec3(1.0), uSSSColorThreshold) * uLightStrength * rad);
                    
	                    if (fragDepth - (bias * 0.1) <= sampleDepth)
	                        dis = vec3(0.0);
                    
	                    falloff = pow(max(1.0 - pow(dis / rad, vec3(uSSSSharpness)), 0.0), 
	                             vec3(uSSSSharpness * 0.5));
	                    subsurf += (falloff / (pow(dis, vec3(2.0)) + 1.0) * att * weight) * uSSSStrength;
	                }
                
	                // Highlight SSS
	                if (uSSSHighlightStrength > 0.01) {
	                    rad = uSSSRadius * sss * (1.0 - uSSSHighlight);
	                    dis = vec3((fragDepth + bias) - sampleDepth) / 
	                         (mix(uLightColor.rgb, vec3(1.0), uSSSHighlightColorThreshold) * uLightStrength * rad);
                    
	                    if (fragDepth - (bias * 0.1) <= sampleDepth)
	                        dis = vec3(0.0);
                    
	                    falloff = pow(max(1.0 - pow(dis / rad, vec3(uSSSHighlightSharpness)), 0.0), 
	                             vec3(uSSSHighlightSharpness * 0.5));
	                    subsurfHighlight += (falloff / (pow(dis, vec3(2.0)) + 1.0) * att * weight) * uSSSHighlightStrength;
	                }
	            }
	        }
        
	        if (weightSum > 0.0) {
	            shadow /= weightSum;
	            if (uSSSHighQuality && sss > 0.001) {
	                subsurf /= weightSum;
	                subsurfHighlight /= weightSum;
	            }
	        } else {
	            shadow = 1.0;
	        }
	    } else {
	        float sampleDepth = uLightNear + (uLightFar - uLightNear) * 
	                          unpackDepth(getFilteredDepth(fragCoord, bufferMin));
	        shadow = ((fragDepth - bias) > sampleDepth) ? 0.0 : 1.0;
	    }
	}

    return shadow;
}

// Material properties
void getMaterial(out float roughness, out float metallic, out float emissive, out float F0, out float sss)
{
    vec4 matColor = texture2D(uTextureMaterial, vTexCoord);
    
    if (uMaterialFormat == 2) { // LabPBR
        if (matColor.g > 0.898) { // Metallic
            metallic = 1.0; F0 = 1.0; sss = 0.0;
        } else { // Non-metallic
            metallic = 0.0; F0 = matColor.g;
            sss = (matColor.b > 0.255 ? (((matColor.b - 0.255) / 0.745) * max(uSSS, uDefaultSubsurface)) : 0.0);
        }
        roughness = pow(1.0 - matColor.r, 2.0);
        emissive = (matColor.a < 1.0 ? matColor.a /= 0.9961 : 0.0) * uDefaultEmissive;
        return;
    }
    
    if (uMaterialFormat == 1) { // SEUS
        roughness = (1.0 - matColor.r);
        metallic = matColor.g;
        emissive = (matColor.b * uDefaultEmissive);
    } else { // No map
        roughness = uRoughness;
        metallic = uMetallic;
        emissive = max(uEmissive, vCustom.z * uDefaultEmissive);
    }
    
    F0 = mix(0.0, 1.0, metallic);
    sss = max(uSSS, vCustom.w * uDefaultSubsurface);
}

// Subsurface scattering
float CSPhase(float dotView, float scatter)
{
    float result = (3.0 * (1.0 - (scatter * scatter))) * (1.0 + dotView);
    result /= 2.0 * (2.0 + pow(scatter, 2.0)) * pow(1.0 + pow(scatter, 2.0) - 2.0 * scatter * dotView, 1.5);
    return result;
}

vec2 getParaboloidCoord(vec3 worldPos, out vec2 bufferMin)
{
    vec3 L = worldPos - uShadowPosition;
    float dist = length(L);
    L /= dist;

    int hemisphere = 0;

    if (L.z < 0.0)
    {
        hemisphere = 1;
        L.z = -L.z;
    }

    float denom = max(L.z + 1.0, 0.0001);
    float m = 2.0 / denom;

    vec2 uv = L.xy * m;
    uv = uv * 0.5 + 0.5;

    if (hemisphere == 0)
    {
        bufferMin = vec2(0.0, 0.0);
        uv.y *= 0.5;
    }
    else
    {
        bufferMin = vec2(0.0, 0.5);
        uv.y = uv.y * 0.5 + 0.5;
    }

    return clamp(uv, bufferMin + 0.001, bufferMin + vec2(1.0, 0.5) - 0.001);
}

void main()
{
    vec3 light, spec = vec3(0.0);
    vec2 tex = vTexCoord;
    vec4 baseColor = texture2D(uTexture, tex) * vColor;
    
    // Alpha hashing
    if (uAlphaHash > 0) {
        if (baseColor.a < hash(vec2(hash(vPosition.xy + (uSampleIndex / 255.0)), vPosition.z + (uSampleIndex / 255.0))))
            discard;
        else
            baseColor.a = 1.0;
    }
    
    if (uIsSky > 0) {
        light = vec3(0.0);
        spec = vec3(uLightSpecular);
    } else {
        // Get material properties
        float roughness, metallic, emissive, F0, sss;
        getMaterial(roughness, metallic, emissive, F0, sss);
        vec3 normal = getMappedNormal(vTexCoord);
        
        float shadow = 1.0;
        float att = 0.0;
        vec3 subsurf = vec3(0.0);
        vec3 subsurfHighlight = vec3(0.0);
        
        // Diffuse factor
        float dif = max(0.0, dot(normal, normalize(uLightPosition - vPosition))); 
        
        // Improved attenuation with smooth transitions
        float fadeStart = uLightFar * (1.0 - uLightFadeSize);
        float fadeEnd = uLightFar;
        float dist = distance(vPosition, uLightPosition);
        att = 1.0 - smoothstep(fadeStart, fadeEnd, dist);
        att *= smoothstep(0.0, uLightNear * 2.0, dist);
        dif *= att;
        
        if (dif > 0.0 || sss > 0.0) {
            vec2 fragCoord, bufferMin;
			
			if (uParaboloid)
			{
				fragCoord = getParaboloidCoord(vPosition, bufferMin);
			}
			else
			{
				vec3 toLight = vPosition - uShadowPosition;
	            
				vec4 lookDir = vec4(
	                toLight.x / distance(vPosition.xy, uShadowPosition.xy),
	                toLight.y / distance(vPosition.xy, uShadowPosition.xy),
	                toLight.z / distance(vPosition.xz, uShadowPosition.xz),
	                toLight.z / distance(vPosition.yz, uShadowPosition.yz)
	            );
            
	            // Determine shadow map face
	            if (lookDir.z > SQRT05 && lookDir.w > SQRT05) { // Z+
	                fragCoord = getShadowMapCoord(vec3(0.0, -0.0001, 1.0));
	                fragCoord.x += 1.0/3.0;
	                fragCoord.y += 0.5;
	                bufferMin = vec2(1.0/3.0, 0.5);
	            } else if (lookDir.z < -SQRT05 && lookDir.w < -SQRT05) { // Z-
	                fragCoord = getShadowMapCoord(vec3(0.0, -0.0001, -1.0));
	                fragCoord.x += 2.0/3.0;
	                fragCoord.y += 0.5;
	                bufferMin = vec2(2.0/3.0, 0.5);
	            } else if (lookDir.x > SQRT05) { // X+
	                fragCoord = getShadowMapCoord(vec3(1.0, 0.0, 0.0));
	                bufferMin = vec2(0.0);
	            } else if (lookDir.x < -SQRT05) { // X-
	                fragCoord = getShadowMapCoord(vec3(-1.0, 0.0, 0.0));
	                fragCoord.x += 1.0/3.0;
	                bufferMin = vec2(1.0/3.0, 0.0);
	            } else if (lookDir.y > SQRT05) { // Y+
	                fragCoord = getShadowMapCoord(vec3(0.0, 1.0, 0.0));
	                fragCoord.x += 2.0/3.0;
	                bufferMin = vec2(2.0/3.0, 0.0);
	            } else { // Y-
	                fragCoord = getShadowMapCoord(vec3(0.0, -1.0, 0.0));
	                fragCoord.y += 0.5;
	                bufferMin = vec2(0.0, 0.5);
	            }
			}
            
            // Calculate bias and shadow
            float cosTheta = clamp(dot(normal, normalize(uLightPosition - vPosition)), 0.0, 1.0);
			float bias = (mix(3.6, 0.1, cosTheta) + (uLightSize * 100.0)) * uBias + (dist / 356.0);

            float fragDepth = distance(vPosition, uShadowPosition);
            
            shadow = calculateShadow(fragCoord, bufferMin, fragDepth, bias, att, subsurf, subsurfHighlight, sss);
            
            // Fallback SSS for non-high quality or small light size
            if ((!uSSSHighQuality && sss > 0.001) || (uLightSize <= 0.0001 && sss > 0.001)) {
                vec3 rad, dis, falloff;
                
                // Main SSS
                if (uSSSStrength > 0.01) {
                    float sampleDepth = uLightNear + (uLightFar - uLightNear) * unpackDepth(getFilteredDepth(fragCoord, bufferMin));
                    rad = uSSSRadius * sss;
                    dis = vec3((fragDepth + bias) - sampleDepth) / 
                         (mix(uLightColor.rgb, vec3(1.0), uSSSColorThreshold) * uLightStrength * rad);
                    
                    if (fragDepth - (bias * 0.1) <= sampleDepth)
                        dis = vec3(0.0);
                    
                    falloff = pow(max(1.0 - pow(dis / rad, vec3(uSSSSharpness)), 0.0), 
                             vec3(uSSSSharpness * 0.5));
                    subsurf = (falloff / (pow(dis, vec3(2.0)) + 1.0) * att) * uSSSStrength;
                }
                
                // Highlight SSS
                if (uSSSHighlightStrength > 0.01) {
                    float sampleDepth = uLightNear + (uLightFar - uLightNear) * unpackDepth(getFilteredDepth(fragCoord, bufferMin));
                    rad = uSSSRadius * sss * (1.0 - uSSSHighlight);
                    dis = vec3((fragDepth + bias) - sampleDepth) / 
                         (mix(uLightColor.rgb, vec3(1.0), uSSSHighlightColorThreshold) * uLightStrength * rad);
                    
                    if (fragDepth - (bias * 0.1) <= sampleDepth)
                        dis = vec3(0.0);
                    
                    falloff = pow(max(1.0 - pow(dis / rad, vec3(uSSSHighlightSharpness)), 0.0), 
                             vec3(uSSSHighlightSharpness * 0.5));
                    subsurfHighlight += (falloff / (pow(dis, vec3(2.0)) + 1.0) * att) * uSSSHighlightStrength;
                }
            }
        }
        
        // Final lighting calculations
        light = uLightColor.rgb * uLightStrength * dif * shadow;
        
        // Subsurface scattering contribution
        if (sss > 0.001) {
            float transDif = max(0.0, dot(normalize(-normal), normalize(uLightPosition - vPosition)));
            float absorption = CSPhase(dot(normalize(vPosition - uCameraPosition), 
                                     normalize(uLightPosition - vPosition)), uAbsorption);
            
            subsurf *= absorption;
            subsurfHighlight *= absorption;
            
            // Mix both subsurface layers
            light += (mix(uLightColor.rgb, vec3(1.0), uSSSDesaturation) * uLightStrength * 
                     uSSSColor.rgb * transDif * subsurf) * smoothstep(0.0, 0.05, (sss / 50.0));
            light += (mix(uLightColor.rgb, vec3(1.0), uSSSHighlightDesaturation) * uLightStrength * 
                     uSSSColor.rgb * transDif * subsurfHighlight) * smoothstep(0.0, 0.05, (sss / 50.0));
            
            light *= mix(vec3(1.0), uSSSColor.rgb, clamp(sss / 75.0, 0.0, 1.0));
        }
        
        // Specular highlights
        if (uLightSpecular * dif * shadow > 0.0)
		{
            vec3 N = normal;
            vec3 V = normalize(uCameraPosition - vPosition);
            vec3 L = normalize(uLightPosition - vPosition);
            vec3 H = normalize(V + L);
			
			// Increase roughness based on light size
			float lightDist = length(uLightPosition - vPosition);
			float sizeFactor = uLightSize / (lightDist + 0.001) * 1000.0;
			float adjustedRoughness = clamp(roughness + sizeFactor * 0.5, 0.0, 1.0);

			// Recompute the GGX terms with adjusted roughness
			float NDF = distributionGGX(N, H, adjustedRoughness);
			float G = geometrySmith(N, V, L, adjustedRoughness);
			float F = fresnelSchlickRoughness(max(dot(H, V), 0.0), F0, adjustedRoughness);

			float numerator = NDF * G * F;
			float denominator = 4.0 * max(dot(N, V), 0.0) * max(dot(N, L), 0.0) + 0.0001;
			float specular = numerator / denominator;

			// Scale brightness slightly (large lights spread energy wider)
			float sizeAtten = 1.0 / (1.0 + uLightSize * 4.0);

			spec = uLightColor.rgb * shadow * uLightSpecular * dif *
			       (specular * sizeAtten * mix(vec3(1.0), baseColor.rgb, metallic));
        }
    }
    
    // Output
    gl_FragData[0] = vec4(light, baseColor.a);
    gl_FragData[1] = vec4(spec, baseColor.a);
    
    if (baseColor.a == 0.0)
        discard;
}